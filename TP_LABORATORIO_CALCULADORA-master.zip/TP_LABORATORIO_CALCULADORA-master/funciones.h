#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

#endif // FUNCIONES_H_INCLUDED

/** \brief recibe dos numeros de tipo entero
 *
 * \param se realizan con dos numeros de tipo entero
 * \return devuelve la suma de los dos numeros
 *
 */
 int sumar(int,int );
/** \brief recibe dos numeros de tipo entero
 *
 * \param se realizan con dos numeros de tipo entero
 * \return devuelve la resta de los dos numeros
 *
 */
 int restar(int,int);
 /** \brief recibe dos numeros de tipo entero siendo el segundo numero distinto de cero
 *
 * \param se realizan con dos numeros enteros
 * \return devuelve la division de los dos numeros y un mensaje de advertencia si el segundo numero es cero
 *
 */
 int dividir(int,int);
 /** \brief recibe dos numeros de tipo entero
 *
 * \param se realiza con dos numeros de tipo entero
 * \return devuelve la multiplicacion de los dos numeros
 *
 */
 int multiplicar(int,int);
  /** \brief recibeel primer numero ingresado (A)
 *
 * \param se realiza la factorizacion del numero entero
 * \return devuelve el factoreo del numero
 *
 */
 unsigned long factorial(int);
