#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"

int main()
{
    char seguir='s';
    int opcion=0;
    int a;
    int b;
    int flagUno=0;
    int flagDos=0;
    int resultado;
    unsigned long resultadoFact;

    while(seguir=='s')
    {
        printf("---------CALCULADORA---------\n");

        if(flagUno==0){
            printf("1- Ingresar 1er operando (A=x)\n");
        }else{
            printf("1- Ingresar 1er operando (A=%d)\n",a);
        }
        if(flagDos==0){
            printf("2- Ingresar 2do operando (B=x)\n");
        }else{
            printf("2- Ingresar 2do operando (B=%d)\n",b);
        }
        printf("3- Calcular la suma (A+B)\n");
        printf("4- Calcular la resta (A-B)\n");
        printf("5- Calcular la division (A/B)\n");
        printf("6- Calcular la multiplicacion (A*B)\n");
        printf("7- Calcular el factorial (A!)\n");
        printf("8- Calcular todas las operaciones\n");
        printf("9- Salir\n");
        printf("\nSelecione la opcion: ");
        scanf("%d",&opcion);
        switch(opcion)

        {
            case 1:
                system("cls");
                a=primerNumero();
                flagUno=1;
                break;
            case 2:
                system("cls");
                printf("*El primer operando es (A=%d)\n",a);
                b=segundoNumero();
                flagDos=1;
                break;
            case 3:
                system("cls");
                resultado=sumar(a,b);
                printf("*\n\nla suma es : %d\n\n\n\n",resultado);
                break;
            case 4:
                system("cls");
                resultado=restar(a,b);
                printf("\n\n*la resta es : %d\n\n\n\n",resultado);
                break;
            case 5:
                system("cls");
                resultado=dividir(a,b);
                if(b!=0){
                printf("\n\n*la division es : %d\n\n\n\n",resultado);
                }else{
                    printf("");
                }
                break;
            case 6:
                system("cls");
                resultado=multiplicar(a,b);
                printf("\n\n*la multiplicacion es : %d\n\n\n\n",resultado);
                break;
           case 7:
                system("cls");
                resultadoFact=factorial(a);
                printf("\n\n*el factorial es : %lu\n\n\n\n",resultadoFact);
                break;
            case 8:
                system("cls");
                resultado=sumar(a,b);
                printf("\n*la suma es : %d\n",resultado);
                resultado=restar(a,b);
                printf("\n*la resta es : %d\n",resultado);
                resultado=dividir(a,b);
                printf("\n*la division es : %d\n",resultado);
                resultado=multiplicar(a,b);
                printf("\n*la multiplicacion es : %d\n",resultado);
                resultado=factorial(a);
                printf("\n*el factorial es : %d\n\n",resultado);
                break;
            case 9:
                seguir = 'n';
                break;
        }
    }


    return 0;
}
