
int primerNumero(int numeroUno)
{
    int retorno;

    printf("1- Ingresar 1er operando (A=x): \n");
    scanf("%d",&retorno);

    return retorno;
}
int segundoNumero(int numeroDos)
{
    int retorno;

    printf("2- Ingresar 2do operando (B=x): \n");
    scanf("%d",&retorno);

    return retorno;
}
int sumar(int numeroUno,int numeroDos)
{
    int retorno;

    retorno=numeroUno+numeroDos;

    return retorno;
}
int restar(int numeroUno,int numeroDos)
{
    int retorno;

    retorno=numeroUno-numeroDos;

    return retorno;
}
int dividir(int numeroUno,int numeroDos)
{

    int retorno;



   if(numeroDos!=0)
   {
       retorno=numeroUno/numeroDos;
   }else{
    printf("\nNO SE PUEDE DIVIDIR POR CERO\n\n");
   }

    return retorno;
}
int multiplicar(int numeroUno,int numeroDos)
{
    int retorno;

    retorno=numeroUno*numeroDos;


    return retorno;

}
unsigned long factorial(int numeroUno)
{
    unsigned long retorno=1;

    for (int i = 1; i<=numeroUno; i++){
        retorno=retorno*i;
    }

    return retorno;
}
